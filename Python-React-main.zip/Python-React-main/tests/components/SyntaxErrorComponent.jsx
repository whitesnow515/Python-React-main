var React = require('react');

var SyntaxErrorComponent = React.createClass({
    render: function() {
        ?+
    }
});

module.exports = SyntaxErrorComponent;