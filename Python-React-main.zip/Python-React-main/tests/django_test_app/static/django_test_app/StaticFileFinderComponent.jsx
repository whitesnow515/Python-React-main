var React = require('react');

var StaticFileFinderComponent = React.createClass({
    render: function() {
        return <span>You found me.</span>;
    }
});

module.exports = StaticFileFinderComponent;