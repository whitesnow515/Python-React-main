Running the example
===================

Install the dependencies

```
pip install -r requirements.txt
npm install
```

Start the render server

```
node render_server.js
```

Start the python server

```
python example.py
```

And visit [http://127.0.0.1:5000](http://127.0.0.1:5000)