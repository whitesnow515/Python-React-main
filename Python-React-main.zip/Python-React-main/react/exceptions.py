class ComponentSourceFileNotFound(Exception):
    pass


class ReactRenderingError(Exception):
    pass


class RenderServerError(Exception):
    pass