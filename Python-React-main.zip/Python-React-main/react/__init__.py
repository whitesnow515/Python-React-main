__version__ = '4.3.0'

default_app_config = 'react.apps.ReactConfig'